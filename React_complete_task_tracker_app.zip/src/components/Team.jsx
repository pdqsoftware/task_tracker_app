import React from "react"

const Team = () => {
    const fakeDeveloperNames = [
        "Alice Smith",
        "Bob Johnson",
        "Charlie Brown",
        "Diana Martinez",
        "Ethan Williams",
        "Fiona Davis",
        "Aymen el kani"
      ];


    return <div>
        <h2>Developers who worked on the Tasks Tracker App:</h2>
        <ul>
            {fakeDeveloperNames.map((name, index) => (
                <li key={index}>{name}</li>
            ))}
        </ul>
    </div>
}

export default Team;