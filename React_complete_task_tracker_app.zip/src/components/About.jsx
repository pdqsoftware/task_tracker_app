import { Outlet } from 'react-router-dom';
import './About.css'
import React, { useEffect, useState } from "react";

const AboutPage = () => {
  const [joke, setJoke] = useState({ content: null, fetch: true, isFetching: true })
  

  useEffect(() => {
    if(!joke.fetch) return;
    let fetchCount = 0;
    const fetchJoke = async () => {
      try {
        const response = await fetch('https://v2.jokeapi.dev/joke/Programming')
        const data = await response.json()
        if(!data.joke && fetchCount <= 2) {
          fetchJoke()
        } else {
          setJoke({ content: data.joke, fetch: false, isFetching: false })
        }
        fetchCount++
      } catch (error) {
        setJoke({ content: "no joke! reload.", fetch: false, isFetching: false })
        console.error('Error fetching joke', error)
      }
    }

    fetchJoke()

    return () => {
      joke.fetch = false
    }
  }, [joke.fetch, joke])


  return <div className='about-container'>
    <h2>About Our Services</h2>
    <p>We are here to provide you with a simple task tracker app to help you stay organized and manage your tasks efficiently.</p>
    
    <div className='jokes-section'>
      <h3>Programming Joke</h3>
      {joke.isFetching ? "Fetching.." : <span>{joke.content}</span>}
    </div>
  
    <Outlet />
  </div>
  
}

export default AboutPage;